package com.learndm.admobpackaging.adkk

class BackupInsAd(adUnitId: String, clickableNumber: Int, displayableNumber: Int) :
    InsAd(adUnitId, clickableNumber, displayableNumber) {
}