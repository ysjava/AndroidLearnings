package com.learndm.admobpackaging.adkk


class LauncherInsAd(adUnitId: String, clickableNumber: Int, displayableNumber: Int):InsAd(adUnitId, clickableNumber, displayableNumber) {

}