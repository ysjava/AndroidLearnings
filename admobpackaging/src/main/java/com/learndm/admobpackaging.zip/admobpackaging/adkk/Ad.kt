package com.learndm.admobpackaging.adkk

import androidx.appcompat.app.AppCompatActivity

interface Ad {
    fun load()
    fun show(activity: AppCompatActivity)
}